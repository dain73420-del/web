import { type NextRequest, NextResponse } from "next/server"
import { storeOTP, sendSMS, generateOTP } from "@/lib/services/auth"

export async function POST(request: NextRequest) {
  try {
    const { mobile } = await request.json()

    if (!mobile) {
      return NextResponse.json({ message: "Mobile number is required" }, { status: 400 })
    }

    // Generate new OTP
    const otp = generateOTP()
    await storeOTP(mobile, otp)

    const smsMessage = `আপনার নতুন ভেরিফিকেশন কোড: ${otp}। ৫ মিনিটের জন্য বৈধ।`
    await sendSMS(mobile, smsMessage)

    return NextResponse.json({
      message: "New OTP sent successfully",
    })
  } catch (error: any) {
    console.error("[v0] Resend OTP error:", error)
    return NextResponse.json(
      {
        message: error.message || "Internal server error",
      },
      { status: 500 },
    )
  }
}
