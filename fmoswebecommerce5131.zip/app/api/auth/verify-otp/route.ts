import { type NextRequest, NextResponse } from "next/server"
import { verifyOTP } from "@/lib/services/auth"

export async function POST(request: NextRequest) {
  try {
    const { mobile, otp } = await request.json()

    if (!mobile || !otp) {
      return NextResponse.json({ message: "Mobile number and OTP are required" }, { status: 400 })
    }

    // Verify OTP and activate user
    const user = await verifyOTP(mobile, otp)

    return NextResponse.json({
      message: "Account verified successfully",
      user: {
        name: user.name,
        mobile: user.mobile,
        verified: true,
      },
    })
  } catch (error: any) {
    console.error("[v0] OTP verification error:", error)
    return NextResponse.json(
      {
        message: error.message || "Internal server error",
      },
      { status: 400 },
    )
  }
}
