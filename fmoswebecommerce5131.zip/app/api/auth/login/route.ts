import { type NextRequest, NextResponse } from "next/server"
import { loginUser } from "@/lib/services/auth"

export async function POST(request: NextRequest) {
  try {
    const { mobile, password } = await request.json()

    if (!mobile || !password) {
      return NextResponse.json({ message: "Mobile number and password are required" }, { status: 400 })
    }

    // Authenticate user
    const user = await loginUser(mobile, password)

    return NextResponse.json({
      message: "Login successful",
      user,
    })
  } catch (error: any) {
    console.error("[v0] Login error:", error)
    return NextResponse.json(
      {
        message: error.message || "Invalid mobile number or password",
      },
      { status: 401 },
    )
  }
}
