import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET() {
  try {
    const supabase = await createClient()
    if (!supabase) {
      return NextResponse.json({ error: "Database connection not available" }, { status: 500 })
    }

    const { data: products, error } = await supabase
      .from("products")
      .select("*")
      .order("created_at", { ascending: false })

    if (error) {
      console.error("[v0] Error fetching products:", error)
      return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 })
    }

    return NextResponse.json({ products })
  } catch (error) {
    console.error("[v0] Error fetching products:", error)
    return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const productData = await request.json()

    // Validate required fields
    if (!productData.name || !productData.price || !productData.category) {
      return NextResponse.json({ error: "Name, price, and category are required" }, { status: 400 })
    }

    const supabase = await createClient()
    if (!supabase) {
      return NextResponse.json({ error: "Database connection not available" }, { status: 500 })
    }

    const newProductData = {
      name: productData.name,
      description: productData.description || "",
      price: Number.parseFloat(productData.price),
      original_price: productData.originalPrice ? Number.parseFloat(productData.originalPrice) : null,
      category: productData.category,
      brand: productData.brand || "",
      stock: Number.parseInt(productData.stock) || 0,
      sku: productData.sku || "",
      weight: productData.weight ? Number.parseFloat(productData.weight) : null,
      dimensions: productData.dimensions || "",
      is_active: productData.isActive !== false,
      is_featured: productData.isFeatured === true,
      tags: productData.tags ? productData.tags.split(",").map((tag: string) => tag.trim()) : [],
      features: productData.features || [],
      images: productData.images || [],
    }

    const { data: newProduct, error } = await supabase.from("products").insert([newProductData]).select().single()

    if (error) {
      console.error("[v0] Error creating product:", error)
      return NextResponse.json({ error: "Failed to create product" }, { status: 500 })
    }

    return NextResponse.json({
      message: "Product created successfully",
      product: newProduct,
    })
  } catch (error) {
    console.error("[v0] Error creating product:", error)
    return NextResponse.json({ error: "Failed to create product" }, { status: 500 })
  }
}
